

required python modules for finding effectiveness

import sys
import random
import math

import numpy
from collections import defaultdict 
import matplotlib.pyplot as plt 



program can be run as: python3 viterbi.py 

it will print ten viterbi predictions with a sequence size of 14 each 

it will then find the required values and plot the graphs
